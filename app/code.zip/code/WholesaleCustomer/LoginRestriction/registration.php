<?php

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'WholesaleCustomer_LoginRestriction', __DIR__);
