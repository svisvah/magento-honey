<?php
/**
 * Grid Schema Setup.
 * @category  Vendor
 * @package   Vendor_Grid
 * @author    Vendor
 * @copyright Copyright (c) 2010-2017 Vendor Software Private Limited (https://Vendor.com)
 * @license   https://store.Vendor.com/license.html
 */
namespace WholesaleCustomer\ApproveLog\Logger;

class Logger extends \Monolog\Logger
{

}
