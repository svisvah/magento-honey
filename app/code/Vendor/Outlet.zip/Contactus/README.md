# Magelearn_Contactus
Save Magento2 Contactus Data into Database and Display in Admin Grid.
![Admin List](https://i.ibb.co/8NS2qxq/Manage-Contactus-Magento-Admin.png)
![Admin Edit](https://i.ibb.co/HqN7Lrp/Manage-Contactus-Magento-Admin-1.png)
![Admin Add](https://i.ibb.co/4FsWYGp/New-Contactus-Contactus-Magento-Admin.png)



